﻿using System;
using System.IO.Ports;
using System.Windows.Controls;
using System.Windows.Media;


namespace Connecty
{

    // A delegate type for hooking up change notifications.
    public delegate void Rs232SettingsChangedEventHandler(object sender, EventArgs e);

    /// <summary>
    /// Interaktionslogik für Page3.xaml
    /// </summary>
    public partial class settingsPageRs232 : Page
    {

        private SingleConnectionSettings userSettings = new SingleConnectionSettings();
        public bool dataIsValid { get; set; }

        public settingsPageRs232(SingleConnectionSettings settings)
        {
            userSettings = settings;
            InitializeComponent();
            setUiRs232Settings();
            dataIsValid = true;// Their is no Chance to anter false Input :-)

        }


        /// <summary>
        /// Set the ComboBox Values and set the Chosen Index From the Current Settings
        /// </summary>
        /// <param name="param"></param>
        private void setUiRs232Settings()
        {
            // Init the Comboboxes

            // Set the Combobox Params for the Com Port
            cbPort.ItemsSource = SerialPort.GetPortNames();//Get the available ComPorts on the System an drop them to the Combobox

            if (cbPort.Items.IndexOf(userSettings.serialSettings.port) > -1)
            {
                cbPort.SelectedIndex = cbPort.Items.IndexOf(userSettings.serialSettings.port);// Set the ComPort to the Selected Port
            }
            else
            {
                cbPort.SelectedIndex = -1;// Set the Comport to the First Available Port
            }


            // Set the Combox Params for the Baud Rate
            cbBaudrate.ItemsSource = new string[] { "2400", "4800", "9600", "19200", "57600", "115200" };
            cbBaudrate.SelectedIndex = cbBaudrate.Items.IndexOf(userSettings.serialSettings.baud.ToString());

            // Set the Parity Combobox
            cbParity.ItemsSource = new string[] { "Ohne", "Gerade", "Ungerade", "Fest 0", "Fest 1" };
            cbParity.SelectedIndex = cbParity.Items.IndexOf(userSettings.serialSettings.getParityAsString());

            // Set the DataBits TextBox
            tbDataBits.Text = userSettings.serialSettings.dataBits.ToString();

            // Set the StopBits Combobox
            cbStoppbits.ItemsSource = new string[] { "Ohne", "1", "1,5", "2" };
            cbStoppbits.SelectedIndex = cbStoppbits.Items.IndexOf(userSettings.serialSettings.getStopBitsAsString());

        }

        /// <summary>
        /// Funtion to return the User entered Settings
        /// </summary>
        public SingleConnectionSettings getUserParams()
        {
            /*
            For the Comboboxes we have to use SelectedItem otherwise we will discover an old input within the on change event
            SelectionBoxItem is for now on Deprecated in this Project            
            */
            userSettings.serialSettings.port = cbPort.SelectedItem.ToString(); 
            userSettings.serialSettings.baud = Convert.ToInt32(cbBaudrate.SelectedItem.ToString());
            userSettings.serialSettings.setParityWithString(cbParity.SelectedItem.ToString());
            userSettings.serialSettings.dataBits = Convert.ToInt32(tbDataBits.Text);
            userSettings.serialSettings.setStopBitsWithString(cbStoppbits.SelectedItem.ToString());

            // Return the User Settings
            return userSettings;
        }


        /// <summary>
        /// User entered an input
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDataBits_TextChanged(object sender, TextChangedEventArgs e)
        {

            Brush wrongInputBackground = Brushes.Red;
            TextBox currentTextBox = sender as TextBox;

            try
            {
                if ((Convert.ToUInt16(currentTextBox.Text) > 0) && (Convert.ToUInt16(currentTextBox.Text) <= 255))
                {
                    dataIsValid = true;
                    currentTextBox.Background = Brushes.White;
                }
                else
                {
                    dataIsValid = false;
                    currentTextBox.Background = wrongInputBackground;
                }

            }
            catch
            {
                dataIsValid = false;
                currentTextBox.Background = wrongInputBackground;
            }


            // Set the Event that the User Changed an Input
            OnChanged(EventArgs.Empty);

        }


        #region On Change Eventhandler

        // An event that clients can use to be notified whenever the
        // elements of the list change.
        public event Rs232SettingsChangedEventHandler Changed;

        // Invoke the Changed event; called whenever list changes
        protected virtual void OnChanged(EventArgs e)
        {
            if (Changed != null)
                Changed(this, e);
        }

        #endregion


    }
}
