﻿using System.Windows;


namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für SettingsTestWindow.xaml
    /// </summary>
    public partial class SimulationUi : Window
    {

        private PageSimulation_DataGrid simulationPage;


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        public SimulationUi()
        {

            InitializeComponent();


            // Set the Data to the Page
            simulationPage = new PageSimulation_DataGrid();

            // Add the Event Handler
            simulationPage.MsgSendRecived += new MsgSendRecivedEventHandler(msgSend);

            // 
            simulationContentFrame.Content = simulationPage;


        }


        #region Events pass through



        /// <summary>
        /// Update of the Input is Available
        /// </summary>
        /// <param name="newInputMsg"></param>
        public void InputUpdate(MsgData newInputMsg)
        {
            simulationPage.InputUpdate(newInputMsg);
        }

        /// <summary>
        /// msgSend Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void msgSend(object sender, MsgSendRecivedEventArgs e)
        {
            msgSendRecived(e);
        }

        // An event that clients can use to be notified whenever the
        // elements of the list change.
        public event MsgSendRecivedEventHandler MsgSendRecived;

        // Invoke the Changed event; called whenever list changes
        protected virtual void msgSendRecived(MsgSendRecivedEventArgs e)
        {
            if (MsgSendRecived != null)
                MsgSendRecived(this, e);
        }


        #endregion


        /// <summary>
        /// Dispose from the Master
        /// </summary>
        public void Dispose()
        {
            // Call the Close of this Window
            this.Close();
        }

        /// <summary>
        /// Window Closing. Exacuted by the System before the Window is Terminated..
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Call the internal Dispose Function to Terminate all references
            GotToKillThemAll();
        }

        /// <summary>
        /// Function to close and dispose all the depandences
        /// </summary>
        private void GotToKillThemAll()
        {
            simulationPage.Dispose();
        }


    }
}
