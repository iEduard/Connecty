﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Threading;

namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für settingsPageSimulation.xaml
    /// </summary>
    public partial class PageSimulation_DataGrid : Page
    {


        private SimulationInterface simulationInterface;
        private Simulation_State currentSimulationState;
        public ObservableCollection<Simulation_Job> Jobs { get; private set; }


        private DataGridRow lastAktiveRow;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        public PageSimulation_DataGrid()
        {

            // Create the yet empty Job list
            Jobs = new ObservableCollection<Simulation_Job>();


            // Create the Simulation Interface
            simulationInterface = new SimulationInterface(Jobs);
            simulationInterface.RequestStateChange(Simulation_State.Run);
            simulationInterface.MsgSendRecived += new MsgSendRecivedEventHandler(msgSend);
            simulationInterface.SimulationStateChanged += new SimulationStateChangedEventHandler(simStateChenged);
            simulationInterface.AktiveJobChanged += new AktiveJobChangedEventHandler(aktiveJobChanged);



            InitializeComponent();

            DataContext = this;//viewModel;

            //simulationInterface = new SimulationInterface(Jobs);
            updateSimulationStatusUi(Simulation_State.Stop);

        }

        #region UI Design Functions

        /// <summary>
        /// Function is called after load of the Toolbar
        /// In this Function we will hide the Toolbar DropDown Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolBar_Loaded(object sender, RoutedEventArgs e)
        {
            ToolBar toolBar = sender as ToolBar;
            var overflowGrid = toolBar.Template.FindName("OverflowGrid", toolBar) as FrameworkElement;
            if (overflowGrid != null)
            {
                overflowGrid.Visibility = Visibility.Collapsed;
            }
            var mainPanelBorder = toolBar.Template.FindName("MainPanelBorder", toolBar) as FrameworkElement;
            if (mainPanelBorder != null)
            {
                mainPanelBorder.Margin = new Thickness();
            }
        }

        #endregion

        #region Toolbar

        /// <summary>
        /// Toolbar Item Run / Pause
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarStartPausSim_Click(object sender, System.Windows.RoutedEventArgs e)
        {

            switch (currentSimulationState)
            {

                case Simulation_State.Stop:
                    simulationInterface.RequestStateChange(Simulation_State.Run, Jobs);
                    break;

                case Simulation_State.Pause:
                    simulationInterface.RequestStateChange(Simulation_State.Run);
                    break;

                case Simulation_State.Run:
                    simulationInterface.RequestStateChange(Simulation_State.Pause);
                    break;

            }


        }

        /// <summary>
        /// Toolbar Item Stop
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarStopSim_Click(object sender, System.Windows.RoutedEventArgs e)
        {

            if (simulationInterface != null)
            {
                simulationInterface.RequestStateChange(Simulation_State.Stop);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarOpen_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            // Create the neded objects
            Simulation_ImportExport mySimulationExporter = new Simulation_ImportExport();
            LinkedList<Simulation_Job> simulationJobs = mySimulationExporter.ReadSimulationKonfiguration();

            if (simulationJobs != null)
            {
                // Clear all the Data if we loaded an Valid Data
                Jobs.Clear();
                
                foreach (Simulation_Job jobItem in simulationJobs)
                {
                    Jobs.Add(jobItem);
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarSave_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            LinkedList<Simulation_Job> simulationJobs = new LinkedList<Simulation_Job>();
            foreach (Simulation_Job jobItem in Jobs)
            {
                simulationJobs.AddLast(jobItem);
            }

            Simulation_ImportExport mySimulationExporter = new Simulation_ImportExport();
            mySimulationExporter.ExportSimulationDataToFileSystem(simulationJobs);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarAddJob_Click(object sender, RoutedEventArgs e)
        {
            if (JobsDataGrid.SelectedIndex == -1)
            {
                Jobs.Add(new Simulation_Job(Smimulation_SequenceType.WaitFor, "New Item"));
            }
            else
            {
                Jobs.Insert(JobsDataGrid.SelectedIndex + 1, new Simulation_Job(Smimulation_SequenceType.WaitFor, "New Item"));
            }
        }

        /// <summary>
        /// Delete selected Item from Toolbar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarRemoveJob_Click(object sender, RoutedEventArgs e)
        {
            removeItem();
        }

        /// <summary>
        /// Control the Continous Mode.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolBarContinousModeOnOff_Click(object sender, RoutedEventArgs e)
        {

            // Exit the Function if we do not get an Object...
            if (simulationInterface == null)
            {
                return;
            }


            simulationInterface.continiousWorking = !simulationInterface.continiousWorking;

            updateButton();

        }

        #endregion

        #region UI Update from the Simulation Working Thread



        /// <summary>
        /// Event Handler from the Simulation Interface
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void simStateChenged(object sender, SimulationStateUpdateEventArgs e)
        {
            this.Dispatcher.Invoke(DispatcherPriority.Normal, new System.Windows.Threading.DispatcherOperationCallback(delegate
            {
                // Update the UI via a function
                updateSimulationStatusUi(e.simulationState);
                return null;
            }), null);
        }


        /// <summary>
        /// Update the UI with the Current Connection State
        /// </summary>
        /// <param name="currentState"></param>
        private void updateSimulationStatusUi(Simulation_State currentState)
        {
            currentSimulationState = currentState;

            switch (currentState)
            {

                case Simulation_State.Pause:
                    disableUserInput();
                    lSimulationState.Content = "Pausiert";
                    break;

                case Simulation_State.Run:
                    disableUserInput();
                    lSimulationState.Content = "Läuft..";
                    break;

                case Simulation_State.Stop:
                    enableUserInput();
                    lSimulationState.Content = "Gestoppt";

                    // Set the last Row Background back to White
                    if (lastAktiveRow != null)
                    {
                        lastAktiveRow.Background = System.Windows.Media.Brushes.White;
                    }

                    JobsDataGrid.CancelEdit();
                    break;


            }
        }


        private void aktiveJobChanged(object sender, AktiveJobChangedEventArgs e)
        {
            this.Dispatcher.Invoke(DispatcherPriority.Normal, new System.Windows.Threading.DispatcherOperationCallback(delegate
            {
                // Update the UI via a function
                highlightDataGridRow(e.Job);
                return null;
            }), null);
        }

        private void highlightDataGridRow(Simulation_Job job)
        {

            JobsDataGrid.SelectedItem = null;

            if (lastAktiveRow != null)
            {
                lastAktiveRow.Background = System.Windows.Media.Brushes.White;
            }

            lastAktiveRow = (DataGridRow)JobsDataGrid.ItemContainerGenerator.ContainerFromItem(job);
            lastAktiveRow.Background = System.Windows.Media.Brushes.Green;
            

        }



        /// <summary>
        /// Function to control the User Input State
        /// </summary>
        private void disableUserInput()
        {
            // Disable the MenuBar
            toolBarAddJob.IsEnabled = false;
            JobsDataGrid.IsEnabled = false;

        }

        /// <summary>
        /// Enable the UserINput
        /// </summary>
        private void enableUserInput()
        {
            // Disable the MenuBar
            toolBarAddJob.IsEnabled = true;
            JobsDataGrid.IsEnabled = true;
        }


        #endregion

        #region Events pass through


        /// <summary>
        /// Update of the Input is Available pass it through to the Interface
        /// </summary>
        /// <param name="newInputMsg"></param>
        public void InputUpdate(MsgData newInputMsg)
        {
            if (simulationInterface != null)
            {
                simulationInterface.InputUpdate(newInputMsg);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void msgSend(object sender, MsgSendRecivedEventArgs e)
        {
            msgSendRecived(e);
        }


        // An event that clients can use to be notified whenever the
        // elements of the list change.
        public event MsgSendRecivedEventHandler MsgSendRecived;

        // Invoke the Changed event; called whenever list changes
        protected virtual void msgSendRecived(MsgSendRecivedEventArgs e)
        {
            if (MsgSendRecived != null)
                MsgSendRecived(this, e);
        }




        #endregion




        /// <summary>
        /// Remove selected from the Listview item
        /// </summary>
        private void removeItem()
        {
            // Escape if their is no selection
            if (JobsDataGrid.SelectedIndex == -1)
            {
                return;
            }

            // get the current selection
            int selectedIndex = JobsDataGrid.SelectedIndex;



            // Remmove the selected Item
            Jobs.RemoveAt(JobsDataGrid.SelectedIndex);

            // Change the Selected index
            if (Jobs.Count <= selectedIndex)
            {
                selectedIndex--;
            }

            // Set the new Selection
            JobsDataGrid.SelectedIndex = selectedIndex;

            // Set the Focus to the Object. So we see the right Selection color
            JobsDataGrid.Focus();
        }


        /// <summary>
        /// Update the UI with the new Button Style
        /// </summary>
        private void updateButton()
        {

            if (simulationInterface.continiousWorking)
            {
                toolBarContinousModeOnOff.Background = System.Windows.Media.Brushes.LightGreen;
            }
            else
            {
                toolBarContinousModeOnOff.Background = System.Windows.Media.Brushes.LightPink;
            }

        }


        public void Dispose()
        {
            // If the Window is Closed stop the Thread
            if (simulationInterface != null)
            {
                simulationInterface.RequestStateChange(Simulation_State.Stop);
            }
        }


        #region Debug the Bug
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lSimulationState_MouseDown(object sender, MouseButtonEventArgs e)
        {

           

        }

        #endregion


    }

}
