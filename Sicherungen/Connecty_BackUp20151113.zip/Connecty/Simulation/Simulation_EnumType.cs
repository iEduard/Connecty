﻿
namespace Connecty
{
    public enum Smimulation_SequenceType
    {
        Send = 0,
        WaitFor = 1,
        Delay = 2,
    }


    public enum Simulation_State
    {
        Stop = 0,
        Pause  = 1,
        Run = 2,

    }



}
