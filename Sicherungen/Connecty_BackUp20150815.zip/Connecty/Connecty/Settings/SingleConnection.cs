﻿using System;
using System.Runtime.Serialization;


namespace Connecty
{
    [Serializable()]
    public class SingleConnection : ISerializable
    {
        /// <summary>
        /// 1 = TCP IP / 2 = RS232
        /// </summary>
        public int currentConnectionSetting { get; set; }
        public rs232Settings serialSettings { get; set; } // Com Port Settings
        public tcpIpSettings tcpSettings { get; set; } // TCP Settings


        /// <summary>
        /// Construtor
        /// </summary>
        public SingleConnection()
        {
            currentConnectionSetting = 1;
            serialSettings = new rs232Settings();
            tcpSettings = new tcpIpSettings();

        }

        /// <summary>
        /// Function that returns a Human readable Text of the Current Settungs
        /// This Text can be displayed to the user
        /// </summary>
        /// <returns></returns>
        public string getSettingsInfo()
        {
            string sSettingsAsText;

            if (currentConnectionSetting == 1)
            {
                sSettingsAsText = "TCP: " + tcpSettings.clientServerSelection + " @";

                if (tcpSettings.clientServerSelection == "Client")
                {
                    sSettingsAsText += tcpSettings.ip;
                }

                else if (tcpSettings.clientServerSelection == "Server")
                {
                    sSettingsAsText += "Alle vorhandenen IP's";
                }

                sSettingsAsText += (":" + tcpSettings.port.ToString());

            }
            else if (currentConnectionSetting == 2)
            {
                sSettingsAsText = "Seriell: @" + serialSettings.port;
            }
            else
            {
                sSettingsAsText = "";
            }

            return sSettingsAsText;
        }

        /// <summary>
        /// Serialize helper function to get the saved data from the File
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ctxt"></param>
        public SingleConnection(SerializationInfo info, StreamingContext ctxt)
        {
            try
            {
                this.currentConnectionSetting = (int)info.GetValue("connection", typeof(int));

            }
            catch (Exception Err)
            {
                this.currentConnectionSetting = 1;
                Console.WriteLine("Das laden der verbindungseinstellung hat nicht geklappt");
            }


            try
            {
                this.serialSettings = (rs232Settings)info.GetValue("rs232Settings", typeof(rs232Settings));
            }
            catch (Exception Err)
            {
                this.serialSettings = new rs232Settings();
                Console.WriteLine("Das laden der verbindungseinstellung hat nicht geklappt");
            }


            try
            {
                this.tcpSettings = (tcpIpSettings)info.GetValue("tcpIpSettings", typeof(tcpIpSettings));
            }
            catch (Exception Err)
            {
                this.tcpSettings = new tcpIpSettings();
                Console.WriteLine("Das laden der verbindungseinstellung hat nicht geklappt");
            }
        }

        /// <summary>
        /// Serialize helper function to write the data to the File
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ctxt"></param>
        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("connection", this.currentConnectionSetting);
            info.AddValue("rs232Settings", this.serialSettings);
            info.AddValue("tcpIpSettings", this.tcpSettings);
        }


    }
}
