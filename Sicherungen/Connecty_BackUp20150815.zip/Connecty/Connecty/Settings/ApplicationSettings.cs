﻿using System;
using System.Runtime.Serialization;


namespace Connecty
{
    [Serializable()]
    public class ApplicationSettings : ISerializable
    {

        /// <summary>
        ///  Define the Class Variables
        /// </summary>
        public int msgLogRingBufferSize { get; set; }        // Size of the Ringbuffer for the Msg Log
        public int sendHistorySize { get; set; }             // Count of stored Send Messages 

        /// <summary>
        /// Constructor
        /// </summary>
        public ApplicationSettings()
        {
            msgLogRingBufferSize = 4096;
            sendHistorySize = 20;
        }



        /// <summary>
        /// Load the Settings from the  inary file...
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ctxt"></param>
        public ApplicationSettings(SerializationInfo info, StreamingContext ctxt)
        {
            try
            {
                this.msgLogRingBufferSize = (int)info.GetValue("msgLogRingBufferSize", typeof(int));
            }
            catch(Exception err)
            {
                this.msgLogRingBufferSize = 255;

                Console.WriteLine("Das laden der Buffer Einstellungen hat nicht geklappt");
            }

            try
            {
                this.sendHistorySize = (int)info.GetValue("sendHistorySize", typeof(int));
            }
            catch (Exception err)
            {
                this.sendHistorySize = 20;
                Console.WriteLine("Das laden der Buffer Einstellungen hat nicht geklappt");

            }
        }

        /// <summary>
        /// Add the Settings 
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ctxt"></param>
        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("msgLogRingBufferSize", this.msgLogRingBufferSize);
            info.AddValue("sendHistorySize", this.sendHistorySize);
        }


    }
}
