﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Text.RegularExpressions;

namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        // Create the object of the Settings
        private ConnectySetings settings;

        private SingleConnectionInterface singleConnection; // Interface for the Connections
        private MultiConnectionInterface multiConnection; // Interface for the Connections


        private MsgLogHandler msgLog = new MsgLogHandler(512); // the Message Log Data 
        private MsgData currentSendData = new MsgData(); // This is a helper for the connversion of the Text in the SendBox to the new requested View Settings
        

        // Heare are some Routed Commands for the Hot Keys. Yes they are realy hot
        public static RoutedCommand connectRoutedCommand = new RoutedCommand();
        public static RoutedCommand disconnectRoutedCommand = new RoutedCommand();
        public static RoutedCommand changeViewUpRoutedCommand = new RoutedCommand();
        public static RoutedCommand changeViewDownRoutedCommand = new RoutedCommand();
        public static RoutedCommand settingsRoutedCommand = new RoutedCommand();
        public static RoutedCommand resetMsgLogRoutedCommand = new RoutedCommand();


        /// <summary>
        /// Main Window Constructor
        /// </summary>
        public MainWindow()
        {

            // Load the Default Settings
            settings = LoadSave.loadSettings(System.AppDomain.CurrentDomain.BaseDirectory);

            // Set the Settings to the Corresponding Objects
            singleConnection = new SingleConnectionInterface(this);
            multiConnection = new MultiConnectionInterface(this);

            singleConnection.connectionSettings = settings.connectionSettings; // Set the Current Settings to the Object
            multiConnection.connectionSettings = settings.connectionSettings;
            msgLog.viewSettings = settings.viewSettings;


            // Init the UI
            InitializeComponent();

            // Add some Hot Keys and bind the Eventhandlers to the UI
            AddHotKeys();

            // Init the UI
            tbSendData.Text = "";// Erase the Textbox Send Data
            updateMainWindowTitle();// Update the Main Window Title
            UpdateStatusBarConnectionState();//Update the StatusBar
            
            // Update the UI with the Current View Settings
            UpdateViewStateDependence(msgLog.viewSettings);

        }


        #region Taskbar Interface

        /// <summary>
        /// Taskbar Button was Pressed Connect
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbConnect_Click(object sender, EventArgs e)
        {
            if (settings.connectionSettings.functionSelect == 0)
            {
                singleConnection.Connect();
            }
            else if (settings.connectionSettings.functionSelect == 1)
            {
                multiConnection.Connect();
            }

        }

        /// <summary>
        /// Taskbar Button was Pressed Siconnect
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbDisconnect_Click(object sender, EventArgs e)
        {
            singleConnection.Disconnect();
            multiConnection.Disconnect();

        }


        #endregion


        #region Menu Items

        /// <summary>
        /// Menu Item About
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItemAbout_Click(object sender, RoutedEventArgs e)
        {
            // Open the About Dialog
            InfoDialog AboutDialog = new InfoDialog();

            // Set the position of the Settings Dialog to the Connecty Main Window...
            var currentWindowPosition = this.PointToScreen(new Point(0, 0));
            AboutDialog.Left = currentWindowPosition.X + (this.Width/2) - (AboutDialog.Width/2);
            AboutDialog.Top = currentWindowPosition.Y + (this.Height/2) - (AboutDialog.Height/2);

            AboutDialog.ShowDialog();

        }

        /// <summary>
        /// View Binary Values of the In and Outgoing Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItem_ViewRepresentationChange_Click(object sender, RoutedEventArgs e)
        {

            MenuItem menuItemSender = sender as MenuItem;

            // Save the current SendBox Data with the Current View Settings
            try
            {
                currentSendData = msgLog.getRawMsgWithCurrentViewSettings(tbSendData.Text);
            }
            catch
            {
                currentSendData = msgLog.getRawMsgWithCurrentViewSettings("");
            }

            // Set the Current View Configuration
            try
            {
                settings.viewSettings.dataPresentation = (Int32)menuItemSender.Resources["ViewRepresentation"];
            }
            catch
            {
                settings.viewSettings.dataPresentation = 0;
            }


            msgLog.viewSettings = settings.viewSettings;

            // Update the StatusBar
            UpdateViewStateDependence(msgLog.viewSettings);
        }

        /// <summary>
        /// View the MsgLog with the TimeStamp
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItem_TimeStamp_Click(object sender, RoutedEventArgs e)
        {

            if (settings.viewSettings.showTimeStamp)
            {
                settings.viewSettings.showTimeStamp = false;
                menuItem_TimeStamp.IsChecked = false;
            }
            else
            {
                settings.viewSettings.showTimeStamp = true;
                menuItem_TimeStamp.IsChecked = true;
            }


            // Update the Msg Log Settings
            msgLog.viewSettings = settings.viewSettings;


            // Update the Msg Log
            reloadRtb();
        }


        #endregion


        #region UI Update functions


        /// <summary>
        /// Update the Rich Text Box from the UI Thread
        /// </summary>
        /// <param name="Text"></param>
        /// <param name="Color"></param>
        private void UpdateRTB(MsgData msg)
        {
            // Define some Helper Variables
            var sb = new StringBuilder();
            TextRange range = new TextRange(rtbInOutData.Document.ContentEnd, rtbInOutData.Document.ContentEnd);
            
            // Return the Msg with the Current View Configuration
            switch (msg.type)
            {
                case MsgData.messageType.recived:// MSG Type Recived
                    if ( msgLog.viewSettings.showTimeStamp )
                    {
                        range.Text = "\n";
                        range.Text += msg.timeStamp.ToString() + ": ";


                        if (settings.connectionSettings.functionSelect == 1)
                        {
                            range.Text += " Verbindung ";
                            range.Text += msg.connectionNumber.ToString();
                            range.Text += ": ";

                        }
                        else
                        {
                            range.Text += " In: ";
                        }


                        range.Text += msgLog.getMsgWithCurrentViewSettings(msg);
                    }
                    else
                    {
                        range.Text = msgLog.getMsgWithCurrentViewSettings(msg);
                    }

                    range.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(settings.viewSettings.receiveColor));
                    break;

                case MsgData.messageType.send:// MSG Type Sended

                    if (msgLog.viewSettings.showTimeStamp)
                    {
                        range.Text = "\n";
                        range.Text += msg.timeStamp.ToString() + ": ";
                        range.Text += " Out: ";
                        range.Text += msgLog.getMsgWithCurrentViewSettings(msg);
                    }
                    else
                    {
                        range.Text = msgLog.getMsgWithCurrentViewSettings(msg);
                    }


                    range.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(settings.viewSettings.sendColor));
                    break;

                case MsgData.messageType.infoPositive:// MSG Type Info Positive

                    sb.Append("\n-----------------------------------------------------------\n");
                    sb.Append(msgLog.getMsgWithCurrentViewSettings(msg));
                    sb.Append("\n-----------------------------------------------------------\n ");
                    range.Text = sb.ToString();
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, System.Windows.Media.Brushes.Green);
                    break;

                case MsgData.messageType.infoNegative:// MSG Type Info Negative

                    sb.Append("\n-----------------------------------------------------------\n");
                    sb.Append(msgLog.getMsgWithCurrentViewSettings(msg));
                    sb.Append("\n-----------------------------------------------------------\n ");
                    range.Text = sb.ToString();

                    range.ApplyPropertyValue(TextElement.ForegroundProperty, System.Windows.Media.Brushes.Red);
                    break;

                // Default View
                default:
                    range.Text = msgLog.getMsgWithCurrentViewSettings(msg);
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, System.Windows.Media.Brushes.Black);
                    break;
            }

            rtbInOutData.ScrollToEnd();// Scroll to the end of teh RichTextBox
        }

        /// <summary>
        /// Update the Rich Text Box from an other Thread
        /// </summary>
        /// <param name="message"></param>
        /// <param name="messageColor"></param>
        public void UpdateRTBAndSafeDataOnDifferentThread(MsgData newMsg)
        {
            this.Dispatcher.Invoke(DispatcherPriority.Normal, new System.Windows.Threading.DispatcherOperationCallback(delegate
            {
                // Store the Data to the msg Log Handler
                msgLog.Add(newMsg);

                // Update the RichtextBox
                UpdateRTB(newMsg);

                return null;
            }), null);
        }

        /// <summary>
        /// TextBox "Send Data" Layout has changed 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbSendData_LayoutUpdated(object sender, EventArgs e)
        {
            ScrollViewer sv = FindVisualChild<ScrollViewer>(tbSendData);

            if (sv != null)
            {
                if (sv.ComputedHorizontalScrollBarVisibility == System.Windows.Visibility.Visible)
                {
                    tbSendData.Height = 40;
                    bSend.Height = 40;
                }
                else
                {
                    tbSendData.Height = 25;
                    bSend.Height = 25;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="depObj"></param>
        /// <returns></returns>
        public static T FindVisualChild<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        return (T)child;
                    }

                    T childItem = FindVisualChild<T>(child);
                    if (childItem != null) return childItem;
                }
            }
            return null;
        }

        /// <summary>
        /// Update the Main Window Title
        /// </summary>
        private void updateMainWindowTitle()
        {
            // Set the Title of the Window to show the Current selected Connection
            this.Title = settings.connectionSettings.getSettingsInfo();
        }

        /// <summary>
        /// Update the Rich Text Box from the UI Thread 
        /// </summary>
        private void UpdateStatusBarConnectionState()
        {
            // Single Connection
            if (settings.connectionSettings.functionSelect == 0)
            {
                setTextBlockView("", tbConnection1State, singleConnection.getConnectionState());
                setTextBlockView("", tbConnection2State, -1);
            }// Connecty in the Middle
            else if (settings.connectionSettings.functionSelect == 1)
            {
                setTextBlockView(" Verbindung 1", tbConnection1State, multiConnection.getConnection1State());
                setTextBlockView(" Verbindung 2", tbConnection2State, multiConnection.getConnection2State());
            }

        }

        /// <summary>
        /// Change the View Of the Textblock
        /// </summary>
        /// <param name="additionalInfo"> Additional String to enter a Pre Info </param>
        /// <param name="textBlockObject"> Textblock object to change </param>
        /// <param name="connectionState"> Status of the Connection </param>
        private void setTextBlockView(string additionalInfo, TextBlock textBlockObject, int connectionState)
        {

            // Return the Msg with the Current View Configuration
            switch (connectionState)
            {

                case -1:// Disabled
                    textBlockObject.Visibility = Visibility.Collapsed;
                    break;

                case 0:// Disconnected
                    textBlockObject.Visibility = Visibility.Visible;
                    textBlockObject.Text = additionalInfo + " Getrennt ";
                    textBlockObject.Background = System.Windows.Media.Brushes.Red;
                    break;

                case 1:// Connecting
                    textBlockObject.Visibility = Visibility.Visible;
                    textBlockObject.Text = additionalInfo + " Verbindungsaufbau... ";
                    textBlockObject.Background = System.Windows.Media.Brushes.Yellow;
                    break;
                case 2:// Disconnecting
                    textBlockObject.Visibility = Visibility.Visible;
                    textBlockObject.Text = additionalInfo + " Verbindungsabbau... ";
                    textBlockObject.Background = System.Windows.Media.Brushes.PaleVioletRed;
                    break;
                case 3:// Connected
                    textBlockObject.Visibility = Visibility.Visible;
                    textBlockObject.Text = additionalInfo + " Verbunden ";
                    textBlockObject.Background = System.Windows.Media.Brushes.Green;
                    break;

                // Default View
                default:
                    textBlockObject.Visibility = Visibility.Visible;
                    textBlockObject.Text = additionalInfo + "...";
                    textBlockObject.Background = System.Windows.Media.Brushes.DimGray;
                    break;
            }
        }

        /// <summary>
        /// Update the StatusBar View State
        /// </summary>
        /// <param name="connectionState"></param>
        private void UpdateViewStateDependence(ViewSettings viewState)
        {
            // Update the View Status
            switch (viewState.dataPresentation)
            {

                case 0:// ASCII
                    tbViewState.Text = " ASCII ";

                    menuItem_BIN.IsChecked = false;
                    menuItem_DEC.IsChecked = false;
                    menuItem_HEX.IsChecked = false;
                    menuItem_ASCII_Zeichen.IsChecked = true;
                    break;

                case 1:// HEX
                    tbViewState.Text = " HEX ";

                    menuItem_BIN.IsChecked = false;
                    menuItem_DEC.IsChecked = false;
                    menuItem_ASCII_Zeichen.IsChecked = false;
                    menuItem_HEX.IsChecked = true;
                    break;

                case 2:// DEC
                    tbViewState.Text = " DEC ";

                    menuItem_BIN.IsChecked = false;
                    menuItem_HEX.IsChecked = false;
                    menuItem_ASCII_Zeichen.IsChecked = false;
                    menuItem_DEC.IsChecked = true;

                    break;

                case 3:// BIN
                    tbViewState.Text = " BIN ";

                    menuItem_HEX.IsChecked = false;
                    menuItem_ASCII_Zeichen.IsChecked = false;
                    menuItem_DEC.IsChecked = false;
                    menuItem_BIN.IsChecked = true;
                    break;

            }


            // Set the TimeStamo View
            if (viewState.showTimeStamp)
            {
                menuItem_TimeStamp.IsChecked = true;
            }
            else
            {
                menuItem_TimeStamp.IsChecked = false;
            }

            
            // Update the Toolbar Color for the Send and Receive View
            tbSendColor.Foreground = new SolidColorBrush(settings.viewSettings.sendColor);
            tbReciveColor.Foreground = new SolidColorBrush(settings.viewSettings.receiveColor);

            // Reloasd the Msg Viewer
            reloadRtb();

        }

        /// <summary>
        /// Update the Rich Text Box from an other Thread
        /// </summary>
        /// <param name="message"></param>
        /// <param name="messageColor"></param>
        public void UpdateStatusBarOnDifferentThread()
        {
            this.Dispatcher.Invoke(DispatcherPriority.Normal, new System.Windows.Threading.DispatcherOperationCallback(delegate
            {
                // Update the RichtextBox
                UpdateStatusBarConnectionState();

                return null;
            }), null);
        }

        /// <summary>
        /// Reload the RichTextBox with the New View Settings
        /// </summary>
        private void reloadRtb()
        {
            // First clear the complete RichTextBox
            rtbInOutData.Document.Blocks.Clear();

            foreach (MsgData msg in msgLog.msgLog)
            {

                string msgValue = msgLog.getMsgWithCurrentViewSettings(msg);
                UpdateRTB(msg);

            }

            // Try to convert the Send Data to the new View Settings
            try
            {
                tbSendData.Text = msgLog.getMsgWithCurrentViewSettings(currentSendData);
            }
            catch (Exception err)
            {
                tbSendData.Text = "";
            }

        }

        /// <summary>
        /// Change the View State 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeViewUp_EventHandler(object sender, RoutedEventArgs e)
        {
            // Save the current SendBox Data with the Current View Settings
            // Save the current SendBox Data with the Current View Settings
            try
            {
                currentSendData = msgLog.getRawMsgWithCurrentViewSettings(tbSendData.Text);
            }
            catch (Exception err)
            {
                currentSendData = msgLog.getRawMsgWithCurrentViewSettings("");
            }

            if (settings.viewSettings.dataPresentation >= 3)
            {
                settings.viewSettings.dataPresentation = 0;
            }
            else
            {
                settings.viewSettings.dataPresentation++;
            }

            msgLog.viewSettings = settings.viewSettings;
            UpdateViewStateDependence(settings.viewSettings);
        }

        /// <summary>
        /// Change the View State
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChangeViewDown_EventHandler(object sender, RoutedEventArgs e)
        {
            // Save the current SendBox Data with the Current View Settings
            try
            {
                currentSendData = msgLog.getRawMsgWithCurrentViewSettings(tbSendData.Text);
            }
            catch (Exception err)
            {
                currentSendData = msgLog.getRawMsgWithCurrentViewSettings("");
            }

            if (settings.viewSettings.dataPresentation <= 0)
            {
                settings.viewSettings.dataPresentation = 3;
            }
            else
            {
                settings.viewSettings.dataPresentation--;
            }

            msgLog.viewSettings = settings.viewSettings;
            UpdateViewStateDependence(settings.viewSettings);
        }

        /// <summary>
        /// Function is called after load of the Toolbar
        /// In this Function we will hide the Toolbar DropDown Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolBar_Loaded(object sender, RoutedEventArgs e)
        {
            ToolBar toolBar = sender as ToolBar;
            var overflowGrid = toolBar.Template.FindName("OverflowGrid", toolBar) as FrameworkElement;
            if (overflowGrid != null)
            {
                overflowGrid.Visibility = Visibility.Collapsed;
            }
            var mainPanelBorder = toolBar.Template.FindName("MainPanelBorder", toolBar) as FrameworkElement;
            if (mainPanelBorder != null)
            {
                mainPanelBorder.Margin = new Thickness();
            }
        }

        #endregion


        /// <summary>
        /// Button Send was Triggerd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Send_Data(object sender, RoutedEventArgs e)
        {
            send(tbSendData.Text);
        }

        /// <summary>
        /// Enter was Pressed on the Textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SendData_KeyDown(object sender, KeyEventArgs e)
        {

            // User wants to send the Data
            if (e.Key == Key.Enter)
            {
                send(tbSendData.Text);
            }

            // User wants to Browse The Send History
            if (e.Key == Key.Up)
            {
                tbSendData.Text = msgLog.getPriviousSendedMsg();
            }

            // User wants to Browse The Send History
            if (e.Key == Key.Down)
            {
                tbSendData.Text = msgLog.getNextSendedMsg();
            }

        }

        /// <summary>
        /// Send Data to the Connected Serial Port
        /// </summary>
        /// <param name="message"></param>
        private void send(string message)
        {
            // If the Message is empty we do not send anything
            if(message == "")
            {
                return;
            }

            // Send the Data
            try
            {
                if (singleConnection.Send(msgLog.getRawMsgWithCurrentViewSettings(message)) == 1)
                {
                    msgLog.messageWasSend(msgLog.getRawMsgWithCurrentViewSettings(message));
                    tbSendData.Text = "";
                }

            }
            catch (Exception err)
            {
                // Configure the message box to be displayed
                string messageBoxText = "Die Eingaben passen nicht zu der aktuellen Darstellung. Bitte Eingaben überprüfen.";
                string caption = "Ungültige Eingabe für das Senden";
                MessageBoxButton button = MessageBoxButton.OK;
                MessageBoxImage icon = MessageBoxImage.Warning;

                // Display message box
                MessageBox.Show(messageBoxText, caption, button, icon);
            }
         }

        /// <summary>
        /// Window Closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Try to save the Settings
            LoadSave.saveSettings(System.AppDomain.CurrentDomain.BaseDirectory, settings);

            // Disconnect the Connections
            singleConnection.Disconnect();
            multiConnection.Disconnect();
        }

        /// <summary>
        /// Help was Called
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HelpExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                UserHelper.showUserHelp();
            }
            catch
            {
                // Configure the message box to be displayed
                string messageBoxText = "Die Hilfedatei konnte nicht erstellt oder geöffnet werden. Bitte die Anwendug auf einem Lokalen Verzeichniss ausführen.";
                string caption = "Fehler in der Hilfedatei";
                MessageBoxButton button = MessageBoxButton.OK;
                MessageBoxImage icon = MessageBoxImage.Warning;

                // Display message box
                MessageBox.Show(messageBoxText, caption, button, icon);
            }
        }


        #region Command Bindings

        /// <summary>
        /// Add the Hot Keys and Key Bindings to the UI
        /// </summary>
        private void AddHotKeys()
        {
            try
            {
                // ----------------------------------------------------------------------------------------------
                // Add the Connect Commands
                CommandBinding cb = new CommandBinding(connectRoutedCommand, Connect_EventHandler);
                this.CommandBindings.Add(cb);
                menuItemVerbinden.Command = connectRoutedCommand;
                toolBarConnect.Command = connectRoutedCommand;

                KeyGesture kg = new KeyGesture(Key.F11, ModifierKeys.None);
                InputBinding ib = new InputBinding(connectRoutedCommand, kg);
                this.InputBindings.Add(ib);

                // ----------------------------------------------------------------------------------------------
                // Add the Disconnect Command
                cb = new CommandBinding(disconnectRoutedCommand, Disconnect_EventHandler);
                this.CommandBindings.Add(cb);
                menuItemTrennen.Command = disconnectRoutedCommand;
                toolBarDisconnect.Command = disconnectRoutedCommand;

                kg = new KeyGesture(Key.F12, ModifierKeys.None);
                ib = new InputBinding(disconnectRoutedCommand, kg);
                this.InputBindings.Add(ib);

                // ----------------------------------------------------------------------------------------------
                // Add the Change View Command UP
                cb = new CommandBinding(changeViewUpRoutedCommand, ChangeViewUp_EventHandler);
                this.CommandBindings.Add(cb);

                kg = new KeyGesture(Key.Left, ModifierKeys.Alt);
                ib = new InputBinding(changeViewUpRoutedCommand, kg);
                this.InputBindings.Add(ib);

                // ----------------------------------------------------------------------------------------------
                // Add the Change View Command Down
                cb = new CommandBinding(changeViewDownRoutedCommand, ChangeViewDown_EventHandler);
                this.CommandBindings.Add(cb);

                kg = new KeyGesture(Key.Right, ModifierKeys.Alt);
                ib = new InputBinding(changeViewDownRoutedCommand, kg);
                this.InputBindings.Add(ib);

                // ----------------------------------------------------------------------------------------------
                // Add the Settings Command
                cb = new CommandBinding(settingsRoutedCommand, Settings_EventHandler);
                this.CommandBindings.Add(cb);
                menuItemEinstellungen.Command = settingsRoutedCommand;
                toolBarConnectionSettings.Command = settingsRoutedCommand;

                kg = new KeyGesture(Key.P, ModifierKeys.Control);
                ib = new InputBinding(settingsRoutedCommand, kg);
                this.InputBindings.Add(ib);

                // ----------------------------------------------------------------------------------------------
                // Add the Erase MsgLog Command
                cb = new CommandBinding(resetMsgLogRoutedCommand, MsgLogReset_EventHandler);
                this.CommandBindings.Add(cb);
                menuItem_MsgLogReset.Command = resetMsgLogRoutedCommand;

                kg = new KeyGesture(Key.R, ModifierKeys.Control);
                ib = new InputBinding(resetMsgLogRoutedCommand, kg);
                this.InputBindings.Add(ib);


            }
            catch (Exception err)
            {
                //handle exception error
            }
        }

        /// <summary>
        /// Open Settings was triggerd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            ConnectySetings loadedSettings = LoadSave.openSettings();

            if (loadedSettings != null)
            {
                settings = loadedSettings;
                updateMainWindowTitle();
                UpdateViewStateDependence(settings.viewSettings);

                // Update the Statusbar
                UpdateStatusBarConnectionState();

                // In case we got a different Connection Settings we will disconnect the Current Connection
                singleConnection.Disconnect();
                singleConnection.connectionSettings = settings.connectionSettings;

                multiConnection.Disconnect();
                multiConnection.connectionSettings = settings.connectionSettings;


            }

        }

        /// <summary>
        /// Safe Settings was triggerd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            LoadSave.saveSettings(settings);
        }

        /// <summary>
        /// Application Close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CloseExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            this.Close();
        }


        #endregion


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Connect_EventHandler(object sender, ExecutedRoutedEventArgs e)
        {
            if (settings.connectionSettings.functionSelect == 0)
            {
                singleConnection.Connect();
            }
            else if (settings.connectionSettings.functionSelect == 1)
            {
                multiConnection.Connect();
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Disconnect_EventHandler(object sender, RoutedEventArgs e)
        {
            singleConnection.Disconnect();
            multiConnection.Disconnect();
        }

        /// <summary>
        /// The MenuItem Cleare the Message Log was Klicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MsgLogReset_EventHandler(object sender, RoutedEventArgs e)
        {

            rtbInOutData.Document.Blocks.Clear();
            msgLog.msgLog.Clear();
        }

        /// <summary>
        /// Menu Item "Parameter"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Settings_EventHandler(object sender, RoutedEventArgs e)
        {
            // Create an Settings View
            SettingsConnectionUi paramWindow = new SettingsConnectionUi(settings.connectionSettings);

            // Set the position of the Settings Dialog to the Connecty Main Window...
            var currentWindowPosition = this.PointToScreen(new Point(0, 0));
            paramWindow.Left = currentWindowPosition.X; // This is not working since the Width of the Window is not set yet => //+ (this.Width/2) - (paramWindow.Width/2);
            paramWindow.Top = currentWindowPosition.Y; // This is not working since the Width of the Window is not set yet => //+ (this.Height/2) - (paramWindow.Height/2);


            if (paramWindow.ShowDialog() == true)
            {
                // Get the User entered Data from the Settings Window
                settings.connectionSettings = paramWindow.getUserParams;
                singleConnection.connectionSettings = settings.connectionSettings; // Set the Current Settings to the Connection Object
                multiConnection.connectionSettings = settings.connectionSettings; // Set the Current Settings to the Connection Object

                // Update the Main Window Title
                updateMainWindowTitle();

                // And also uptade the StatusBar
                UpdateStatusBarConnectionState();

                // Save the Data to the File System
                LoadSave.saveSettings(System.AppDomain.CurrentDomain.BaseDirectory, settings);
            }

        }

        /// <summary>
        /// Search Event was triggerd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchTextBox_Search(object sender, RoutedEventArgs e)
        {

            // First of all reload the Textbox in case we gote some Style we do not want
            UpdateViewStateDependence(settings.viewSettings);

            // Get the Sender as a Search Box
            UIControls.SearchTextBox searchBox = (UIControls.SearchTextBox)sender;

            string mySearchString = searchBox.Text;

            TextRange range = new TextRange(rtbInOutData.Document.ContentStart, rtbInOutData.Document.ContentEnd);
            //range.Text = @"TOP a multiline text or file END";
            Regex reg = new Regex("("+ mySearchString + ")", RegexOptions.Compiled | RegexOptions.IgnoreCase);

            var start = rtbInOutData.Document.ContentStart;
            while (start != null && start.CompareTo(rtbInOutData.Document.ContentEnd) < 0)
            {
                if (start.GetPointerContext(LogicalDirection.Forward) == TextPointerContext.Text)
                {
                    var match = reg.Match(start.GetTextInRun(LogicalDirection.Forward));

                    var textrange = new TextRange(start.GetPositionAtOffset(match.Index, LogicalDirection.Forward), start.GetPositionAtOffset(match.Index + match.Length, LogicalDirection.Backward));
                    textrange.ApplyPropertyValue(TextElement.BackgroundProperty, new SolidColorBrush(Colors.Yellow));
                    textrange.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                    start = textrange.End; // I'm not sure if this is correct or skips ahead too far, try it out!!!
                }
                start = start.GetNextContextPosition(LogicalDirection.Forward);
            }
        }

        /// <summary>
        /// Color of the Send Message was Clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbSendColor_MouseUp(object sender, MouseButtonEventArgs e)
        {

            // Create an Settings View
            ColorPicker paramWindow = new ColorPicker();

            // Set the position of the Dialog to the position of the Mouse
            var currentWindowPosition = PointToScreen(Mouse.GetPosition(this));
            paramWindow.Left = currentWindowPosition.X;
            paramWindow.Top = currentWindowPosition.Y;


            if (paramWindow.ShowDialog() == true)
            {
                settings.viewSettings.sendColor = paramWindow.getColor;

                // Set the Current View Configuration
                msgLog.viewSettings = settings.viewSettings;

                // Update the UI
                UpdateViewStateDependence(msgLog.viewSettings);

            }

        }

        /// <summary>
        /// Color of the Recive Message was Clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbReciveColor_MouseUp(object sender, MouseButtonEventArgs e)
        {

            // Create an Settings View
            ColorPicker paramWindow = new ColorPicker();

            // Set the position of the Dialog to the position of the Mouse
            var currentWindowPosition = PointToScreen(Mouse.GetPosition(this));
            paramWindow.Left = currentWindowPosition.X;
            paramWindow.Top = currentWindowPosition.Y;


            if (paramWindow.ShowDialog() == true)
            {
                settings.viewSettings.receiveColor = paramWindow.getColor;

                // Set the Current View Configuration
                msgLog.viewSettings = settings.viewSettings;

                // Update the UI
                UpdateViewStateDependence(msgLog.viewSettings);

            }
        }

    }
}
