﻿using System.Windows.Controls;


namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für settingsPageSimulation.xaml
    /// </summary>
    public partial class settingsPageSimulation : Page
    {
        public settingsPageSimulation()
        {
            InitializeComponent();
        }
    }
}
