﻿using System.Threading;
using System.Threading.Tasks;

namespace Connecty
{
    class SingleConnectionInterface
    {

        public ConnectionSettings connectionSettings { get; set; }
        private ConnectionInterface connection1; // Interface for the Connections

        private MainWindow uiRef; // Reference to the UI
        private Timer stateTimer; // Timer for the Asynchronous update of the Statusbar


        /// <summary>
        /// Construktor
        /// </summary>
        /// <param name="obj"></param>
        public SingleConnectionInterface(MainWindow obj)
        {
            // Set the UI Reference
            this.uiRef = obj;
            connection1 = new ConnectionInterface(1);
            connection1.MsgLogChanged += new MsgSendRecivedEventHandler(UpdateRTBAndSafeDataOnDifferentThread);
        }

        /// <summary>
        /// Connect Method
        /// </summary>
        public void Connect()
        {

            // First of all we call the Disconnect. Maybe their is a Connection allready Running
            Disconnect();

            // Start the StatusBar Update Ticker
            stateTimer = new Timer(new TimerCallback(updateStatusBar_Tick));
            stateTimer.Change(0, 200);

            // Set the Connection Settings
            connection1.connectionSettings = connectionSettings.connection1; // Set the Current Settings to the Connection Object

            // Start the Connections
            connection1.Connect();
        }

        /// <summary>
        /// Disconnecting Method
        /// </summary>
        public void Disconnect()
        {
            // Disconnect the Connections
            connection1.Disconnect();

        }

        /// <summary>
        /// Try to send the Data to the Requested Connection
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public int Send(MsgData message)
        {

            connection1.Send(message);

            return 1;
        }

        /// <summary>
        /// Update the Statusbar
        /// </summary>
        private void updateStatusBar_Tick(object state)
        {

            uiRef.UpdateStatusBarOnDifferentThread();
        }

        /// <summary>
        /// Return the Current Connection State of the Connection we are using right now...
        /// </summary>
        /// <returns></returns>
        public int getConnectionState()
        {

            int currentConnectionState = 0;

            if (connectionSettings.connection1.currentConnectionSetting == 1)
            {
                if (connection1.tcpConnection != null)
                {
                    currentConnectionState = connection1.tcpConnection.getConnectionState();
                }
            }
            else if (connectionSettings.connection1.currentConnectionSetting == 2)
            {
                if (connection1.serialConnection != null)
                {
                    currentConnectionState = connection1.serialConnection.getConnectionState();
                }
            }

            return currentConnectionState;

        }

        /// <summary>
        /// Redirect the Log Messages Fromm the Connections
        /// </summary>
        /// <param name="logMessage"></param>
        public void UpdateRTBAndSafeDataOnDifferentThread(object sender, MsgLogEventArgs e)
        {
            uiRef.UpdateRTBAndSafeDataOnDifferentThread(e.msgData);
        }

    }
}
