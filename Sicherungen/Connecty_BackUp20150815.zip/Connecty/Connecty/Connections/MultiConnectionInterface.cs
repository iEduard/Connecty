﻿using System.Threading;
using System.Threading.Tasks;

namespace Connecty
{
    class MultiConnectionInterface
    {

        public ConnectionSettings connectionSettings { get; set; }
        private ConnectionInterface connection1; // Interface for the Connections
        private ConnectionInterface connection2; // Interface for the Connections

        private MainWindow uiRef; // Reference to the UI
        private Timer stateTimer; // Timer for the Asynchronous update of the Statusbar


        /// <summary>
        /// Construktor
        /// </summary>
        /// <param name="obj"></param>
        public MultiConnectionInterface(MainWindow obj)
        {
            // Set the UI Reference
            this.uiRef = obj;

            connection1 = new ConnectionInterface(1);
            connection1.interfaceNumber = 1;
            connection1.MsgLogChanged += new MsgSendRecivedEventHandler(UpdateRTBAndSafeDataOnDifferentThread);

            connection2 = new ConnectionInterface(2);
            connection2.interfaceNumber = 2;
            connection2.MsgLogChanged += new MsgSendRecivedEventHandler(UpdateRTBAndSafeDataOnDifferentThread);
        }

        /// <summary>
        /// Connect Method
        /// </summary>
        public void Connect()
        {

            // First of all we call the Disconnect. Maybe their is a Connection allready Running
            Disconnect();

            // Start the StatusBar Update Ticker
            stateTimer = new Timer(new TimerCallback(updateStatusBar_Tick));
            stateTimer.Change(0, 200);

            // Set the Connection Settings
            connection1.connectionSettings = connectionSettings.connection1; // Set the Current Settings to the Connection Object
            connection2.connectionSettings = connectionSettings.connection2; // Set the Current Settings to the Connection Object

            // Start the Connections
            connection1.Connect();
            connection2.Connect();
        }

        /// <summary>
        /// Disconnecting Method
        /// </summary>
        public void Disconnect()
        {
            // Disconnect the Connections
            connection1.Disconnect();
            connection2.Disconnect();
        }

        /// <summary>
        /// Try to send the Data to the Requested Connection
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public int Send(MsgData message, int connectionSelection)
        {
            if (connectionSelection == 1)
            {
                connection1.Send(message);
            }
            else
            {
                connection2.Send(message);
            }

            return 1;
        }

        /// <summary>
        /// Update the Statusbar
        /// </summary>
        private void updateStatusBar_Tick(object state)
        {
            uiRef.UpdateStatusBarOnDifferentThread();
        }

        public int getConnection1State()
        {

            int currentConnectionState = 0;

            if (connectionSettings.connection1.currentConnectionSetting == 1)
            {
                if (connection1.tcpConnection != null)
                {
                    currentConnectionState = connection1.tcpConnection.getConnectionState();
                }
            }
            else if (connectionSettings.connection1.currentConnectionSetting == 2)
            {
                if (connection1.serialConnection != null)
                {
                    currentConnectionState = connection1.serialConnection.getConnectionState();
                }
            }

            return currentConnectionState;

        }


        public int getConnection2State()
        {

            int currentConnectionState = 0;

            if (connectionSettings.connection2.currentConnectionSetting == 1)
            {
                if (connection2.tcpConnection != null)
                {
                    currentConnectionState = connection2.tcpConnection.getConnectionState();
                }
            }
            else if (connectionSettings.connection2.currentConnectionSetting == 2)
            {
                if (connection2.serialConnection != null)
                {
                    currentConnectionState = connection2.serialConnection.getConnectionState();
                }
            }

            return currentConnectionState;

        }

        /// <summary>
        /// Redirect the Log Messages Fromm the Connections
        /// </summary>
        /// <param name="logMessage"></param>
        public void UpdateRTBAndSafeDataOnDifferentThread(object sender, MsgLogEventArgs e)
        {

            ConnectionInterface connection = sender as ConnectionInterface;

            if (e.msgData.type == MsgData.messageType.recived)
            {
                if (connection.interfaceNumber == 1)
                {
                    connection2.Send(e.msgData);
                }
                else
                {
                    connection1.Send(e.msgData);
                }

                uiRef.UpdateRTBAndSafeDataOnDifferentThread(e.msgData);
            }
            else if (e.msgData.type == MsgData.messageType.infoPositive || e.msgData.type == MsgData.messageType.infoNegative)
            {
                uiRef.UpdateRTBAndSafeDataOnDifferentThread(e.msgData);
            }
        }
    }
}
