﻿using System;
using System.Windows.Controls;
using System.Windows.Media;


namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für settingsPageConnectyInTheMiddle.xaml
    /// </summary>
    public partial class settingsPageConnectyInTheMiddle : Page
    {


        private ConnectionSettings currentConnectionSettings;
        private settingsPageConnection connection_1;
        private settingsPageConnection connection_2;


        public bool dataIsValid
        {
            get { return checkisPlausible(); }
        }


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        public settingsPageConnectyInTheMiddle(ConnectionSettings settings)
        {

            currentConnectionSettings = settings;

            // Initialize the UI
            InitializeComponent();

            // Update the UI
            updateUiWithCurrentSettings();

        }

        /// <summary>
        /// This function sets the Data from the Current Settings
        /// </summary>
        private void updateUiWithCurrentSettings()
        {

            // Set the Data to the Left Frame for the Connection 1
            Connection1_Name.Text = currentConnectionSettings.connection1.connectionName;
            connection_1 = new settingsPageConnection(currentConnectionSettings.connection1);
            connection_1.Changed += new SingleConnectionSettingsChangedEventHandler(connectionSettingsChanged);
            settingsContentFrameConnection1.Content = connection_1;

            // Set the Data to the Left Frame for the Connection 2
            Connection2_Name.Text = currentConnectionSettings.connection2.connectionName;
            connection_2 = new settingsPageConnection(currentConnectionSettings.connection2);
            connection_2.Changed += new SingleConnectionSettingsChangedEventHandler(connectionSettingsChanged);
            settingsContentFrameConnection2.Content = connection_2;


            // Check the Plausability. To Show the User Wrong Inputs
            checkisPlausible();
        }

        /// <summary>
        /// Funtion to return the User entered Settings. This Function is called when the Accept button was Pressed
        /// </summary>
        public ConnectionSettings getUserParams()
        {

            // Get the Data from the two Pages
            currentConnectionSettings.connection1 = connection_1.getUserParams();
            currentConnectionSettings.connection1.connectionName = Connection1_Name.Text;

            currentConnectionSettings.connection2 = connection_2.getUserParams();
            currentConnectionSettings.connection2.connectionName = Connection2_Name.Text;

            // Return the User Settings
            return currentConnectionSettings;
        }

        /// <summary>
        /// Get the Valid State from the current Page
        /// </summary>
        /// <returns></returns>
        private bool checkisPlausible()
        {
            bool yesDataIsValid = false;

            SingleConnectionSettings con1 = connection_1.getUserParams();
            SingleConnectionSettings con2 = connection_2.getUserParams();


            if ((connection_1.dataIsValid && connection_2.dataIsValid))
            {
                // Bevor we can compare those Variables we have to figure out wich Interface is used!
                if (con1.currentConnectionSetting == con2.currentConnectionSetting)
                {
                    if (con1.currentConnectionSetting == 1)
                    {
                        // It is not Possible that two Servers listen to the Same Port...
                        if (con1.tcpSettings.clientServerSelection == "Server"
                            && con2.tcpSettings.clientServerSelection == "Server"
                            && con1.tcpSettings.port == con2.tcpSettings.port)
                        {
                            yesDataIsValid = false;
                        }
                        else
                        {
                            yesDataIsValid = true;
                        }
                    }
                    else
                    {
                        if (con1.serialSettings.port == con2.serialSettings.port)
                        {

                            yesDataIsValid = false;
                        }
                        else
                        {
                            yesDataIsValid = true;
                        }
                    }
                }


                // Color the UI for the User to show wich setting is not ok..
                if (!yesDataIsValid)
                {
                    // Set the Boarder Thicknes. To show the user te wrong Input
                    BoarderSettingsContenFrame2.BorderBrush = Brushes.Red;

                }
                else
                {
                    // Hide the Boarder to let the User know that the input is valid
                    BoarderSettingsContenFrame2.BorderBrush = Brushes.LightGray;
                }
            }


            // Check if both Connections are OK
            return yesDataIsValid;
        }

        /// <summary>
        /// This will be called whenever the list changes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void connectionSettingsChanged(object sender, EventArgs e)
        {
            // CHeck the Plausability after every user change
            checkisPlausible();
        }



    }
}
