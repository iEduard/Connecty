﻿using System;
using System.IO;
using System.Windows.Controls;
using System.Windows.Media;


namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für settingsPageConnectyInTheMiddle.xaml
    /// </summary>
    public partial class settingsPageConnectyTheSimulation : Page
    {


        private ConnectionSettings currentConnectionSettings;
        private settingsPageConnection connectionPage;
        private settingsPageSimulation simulationPage;

        public bool dataIsValid
        {
            get { return checkisPlausible(); }
        }


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        public settingsPageConnectyTheSimulation(ConnectionSettings settings)
        {

            currentConnectionSettings = settings;

            // Initialize the UI
            InitializeComponent();

            // Update the UI
            updateUiWithCurrentSettings();

        }

        /// <summary>
        /// This function sets the Data from the Current Settings
        /// </summary>
        private void updateUiWithCurrentSettings()
        {

            // Set the Data to the Left Frame for the Connection 1
            connectionPage = new settingsPageConnection(currentConnectionSettings.connection1);
            connectionPage.Changed += new SingleConnectionSettingsChangedEventHandler(connectionSettingsChanged);
            settingsContentFrameConnection.Content = connectionPage;

            // Set the Data to the Left Frame for the Connection 2

            simulationPage = new settingsPageSimulation(currentConnectionSettings);
            settingsContentFrameSimulation.Content = simulationPage;


            // Check the Plausability. To Show the User Wrong Inputs
            checkisPlausible();
        }

        /// <summary>
        /// Funtion to return the User entered Settings. This Function is called when the Accept button was Pressed
        /// </summary>
        public ConnectionSettings getUserParams()
        {

            // Get the Data from the Connection Page
            currentConnectionSettings.connection1 = connectionPage.getUserParams();

            // Get the Data from the Simulation Page
            simulationPage.getUserParams();

            // Return the User Settings
            return currentConnectionSettings;
        }

        /// <summary>
        /// Get the Valid State from the current Page
        /// </summary>
        /// <returns></returns>
        private bool checkisPlausible()
        {
            bool yesDataIsValid = false;


            yesDataIsValid = connectionPage.dataIsValid;

            // Check if the Connection settings are Valid
            if (connectionPage.dataIsValid)
            {
                try
                {

                    // try to open the File
                    StreamReader testStream = new StreamReader(simulationPage.tbFilePath.Text);

                    // ok the Data is Valid
                    yesDataIsValid = (new Simulation_Parser()).checkPlauseability(testStream);

                    // Close the Stream
                    testStream.Close();
                    

                }
                catch
                {
                    // There is something wrong with the Data... it is not Possible to load the Data
                    yesDataIsValid = true;
                }

            }



            // Check if both Connections are OK
            return yesDataIsValid;
        }

        /// <summary>
        /// This will be called whenever the list changes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void connectionSettingsChanged(object sender, EventArgs e)
        {
            // CHeck the Plausability after every user change
            checkisPlausible();
        }



    }
}
