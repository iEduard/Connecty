﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Controls;


namespace Connecty
{
    /// <summary>
    /// Interaktionslogik für settingsPageSimulation.xaml
    /// </summary>
    public partial class settingsPageSimulation : Page
    {


        LinkedList<Simulation_SingleJob> simulationJobs;
        ObservableCollection<Simulation_SingleJob> observableSimulationJobs;


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        public settingsPageSimulation(ConnectionSettings settings)
        {
            InitializeComponent();

            observableSimulationJobs = new ObservableCollection<Simulation_SingleJob>();

            try
            {
                lbSimulationJobs.ItemsSource = simulationJobs;
            }
            catch
            {
                Console.WriteLine("Hmmm Die Daten werden also nicht wirklich gespeichert");
            }

        }

        /// <summary>
        /// Open File Button was clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btOpendFile_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Connecty Einstellungen laden";
            // openFileDialog.DefaultExt = settingsExtension;
            // openFileDialog.Filter = "Settings (*.cs)|";


            if (openFileDialog.ShowDialog() == true)
            {
                // Set the Path the TextBox
                tbFilePath.Text = openFileDialog.FileName;
            }



            try
            {
                Simulation_Parser myParser = new Simulation_Parser();
                simulationJobs = myParser.ReadSimulationKonfiguration(tbFilePath.Text);

                foreach (Simulation_SingleJob jobItem in simulationJobs)
                {
                    observableSimulationJobs.Add(jobItem);

                }




                lbSimulationJobs.ItemsSource = observableSimulationJobs;//simulationJobs;

                // ComboBoxTest.SelectedIndex

            }
            catch
            {
                Console.WriteLine("Das auslesen der Parameter hat leider nicht geklappt");
                Console.WriteLine("Das auslesen der Parameter hat leider nicht geklappt");
                Console.WriteLine("Das auslesen der Parameter hat leider nicht geklappt");
                Console.WriteLine("Das auslesen der Parameter hat leider nicht geklappt");
            }

        }



        public LinkedList<Simulation_SingleJob> getUserParams()
        {

            return simulationJobs;
        }

        private void btAddItem_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            //simulationJobs.AddLast(new Simulation_SingleJob(Smimulation_SequenceType.WaitFor, "New Item"));
            observableSimulationJobs.Add(new Simulation_SingleJob(Smimulation_SequenceType.WaitFor, "New Item"));
            //lbSimulationJobs.BeginInit(); // .UpdateLayout();
        }
    }
}
