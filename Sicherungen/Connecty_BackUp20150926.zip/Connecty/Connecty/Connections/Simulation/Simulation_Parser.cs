﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Connecty
{

    /// <summary>
    ///  Function to read / load the Simulatoin konfiguration
    /// </summary>
    class Simulation_Parser
    {

        // Define some String Constants for the Syntax
        const string startSequence = "#StartAblauf";
        const string endSequence = "#EndeAblauf";
        const string waitForMsg = "WarteAuf";
        const string sendMsg = "Sende";
        const string delayMsg = "Warte";


        private LinkedList<Simulation_SingleJob> sequenceJobs = new LinkedList<Simulation_SingleJob>();


        /// <summary>
        /// Read the Simulation Konfiguration and add the Jobs to the linked list
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public LinkedList<Simulation_SingleJob> ReadSimulationKonfiguration(string path)
        {

            int counter = 0;
            string line;

            bool startFound = false;
            bool endFound = false;


            // Read the file and display it line by line.
            StreamReader file = new StreamReader(path);

            //Read the Data Line by Line 
            while ((line = file.ReadLine()) != null)
            {

                if (line.Contains(startSequence))
                {
                    startFound = true;
                }

                if (line.Contains(endSequence))
                {
                    endFound = true;
                }

                // If we are in the Sequence we check for the Requested Data
                if (startFound == true && endFound == false)
                {
                    checkForSimulationWork(line);
                }

                Console.WriteLine(line);
                counter++;
            }

            // Close the File
            file.Close();

            // Return the Jobs in a Linked List
            return sequenceJobs;

        }


        /// <summary>
        /// Function to check the Plausebility
        /// </summary>
        /// <returns></returns>
        public bool checkPlauseability(StreamReader file)
        {

            bool dataIsValid = true;

            // Read the complete Data to a String
            string SimulationData = file.ReadToEnd();

            int startPoint = SimulationData.IndexOf(startSequence);
            int endPoint = SimulationData.IndexOf(startSequence);


            if ( (SimulationData.IndexOf(startSequence) != SimulationData.LastIndexOf(startSequence))
                || SimulationData.IndexOf(startSequence) == -1)
            {
                dataIsValid = false;

            }

            if ((SimulationData.IndexOf(endSequence) != SimulationData.LastIndexOf(endSequence))
                || SimulationData.IndexOf(endSequence) == -1)
            {
                dataIsValid = false;

            }



            return dataIsValid;

        }


        /// <summary>
        /// Check for the Jobs in the Textfile
        /// </summary>
        /// <param name="inputData"></param>
        private void checkForSimulationWork(string inputData)
        {

            if (inputData.Contains(waitForMsg))
            {
                sequenceJobs.AddLast(new Simulation_SingleJob(Smimulation_SequenceType.WaitFor, getMsgData(inputData)));
            }
            else if (inputData.Contains(sendMsg))
            {
                sequenceJobs.AddLast(new Simulation_SingleJob(Smimulation_SequenceType.Send, getMsgData(inputData)));
            }
            else if (inputData.Contains(delayMsg))
            {
                sequenceJobs.AddLast(new Simulation_SingleJob(Smimulation_SequenceType.Delay, getMsgData(inputData)));
            }

        }

        /// <summary>
        /// Get the Substring of the Jobs
        /// </summary>
        /// <param name="inputData"></param>
        /// <returns></returns>
        private string getMsgData(string inputData)
        {

            int startIndex = inputData.IndexOf("(");
            int endIndex = inputData.IndexOf(")");

            return inputData.Substring(startIndex + 1, endIndex - startIndex - 1);

        }


    }
}