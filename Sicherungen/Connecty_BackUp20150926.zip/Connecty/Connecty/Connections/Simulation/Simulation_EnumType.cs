﻿
namespace Connecty
{
    public enum Smimulation_SequenceType
    {
        Send = 0,
        WaitFor = 1,
        Delay = 2,
    }
}
