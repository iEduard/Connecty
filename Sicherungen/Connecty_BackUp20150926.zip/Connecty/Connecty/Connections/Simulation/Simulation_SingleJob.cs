﻿
namespace Connecty
{
    public class Simulation_SingleJob
    {

        // Klass Variables
        //public Smimulation_SequenceType type { get; set; }
        public int type { get; set; }
        public int delay { get; set; }
        public string message { get; set; }
        public string[] cbItemSource { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        public Simulation_SingleJob(Smimulation_SequenceType paramType, int paramDelay)
        {
           // this.itype = (int)paramType;
            this.type = (int)paramType;
            this.delay = paramDelay;

            cbItemSource = new string[] { "Send", "WaitFor", "Delay" };
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public Simulation_SingleJob(Smimulation_SequenceType paramType, string paramMessage)
        {
            //this.itype = (int)paramType;
            this.type = (int)paramType;
            this.message = paramMessage;

            cbItemSource = new string[]{ "Send", "WaitFor", "Delay" };
        }

    }
}
