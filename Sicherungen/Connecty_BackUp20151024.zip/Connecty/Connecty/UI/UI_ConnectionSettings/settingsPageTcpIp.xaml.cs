﻿using System;
using System.Net;
using System.Windows.Controls;
using System.Windows.Media;
using System.Collections;


namespace Connecty
{

    // A delegate type for hooking up change notifications.
    public delegate void TcpIpSettingsChangedEventHandler(object sender, EventArgs e);

    /// <summary>
    /// Interaktionslogik für Page2.xaml
    /// </summary>
    public partial class settingsPageTcpIp : Page
    {

        private SingleConnectionSettings userSettings = new SingleConnectionSettings();
        public bool dataIsValid { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        public settingsPageTcpIp(SingleConnectionSettings settings)
        {
            userSettings = settings;
            InitializeComponent();
            setUiTcpIpSettings();

        }


        /// <summary>
        /// Set the ComboBox Values and set the Chosen Index From the Current Settings
        /// </summary>
        /// <param name="param"></param>
        private void setUiTcpIpSettings()
        {
            // Init the Comboboxes

            // Set the Combox Params for the ClientServer Selection
            cbClientServerSelect.ItemsSource = new string[] { "Client", "Server" };
            cbClientServerSelect.SelectedIndex = cbClientServerSelect.Items.IndexOf(userSettings.tcpSettings.clientServerSelection);

            cbTcpAutomaticReconnect.IsChecked = userSettings.tcpSettings.restartTcpServer;

            // Set the IP Address TextBox
            setIpTextBoxData();

            // Set the Port TextBox
            tbTcpIpPort.Text = userSettings.tcpSettings.port.ToString();

        }

        /// <summary>
        /// Update the IP TextBox
        /// </summary>
        private void setIpTextBoxData()
        {
            if (cbClientServerSelect.SelectedItem.ToString().Equals("Server"))
            {
                tbTcpIpAddress.Text = "Alle verfügbaren";
                tbTcpIpAddress.IsEnabled = false;
            }
            else
            {
                tbTcpIpAddress.Text = userSettings.tcpSettings.ip;
                tbTcpIpAddress.IsEnabled = true;
            }
        }


        /// <summary>
        /// Funtion to return the User entered Settings
        /// </summary>
        public SingleConnectionSettings getUserParams()
        {

            /*
            For the Comboboxes we have to use SelectedItem otherwise we will discover an old input within the on change event
            SelectionBoxItem is for now on Deprecated in this Project            
            */
            userSettings.tcpSettings.clientServerSelection = cbClientServerSelect.SelectedItem.ToString();
            userSettings.tcpSettings.port = Convert.ToInt32(tbTcpIpPort.Text);
            userSettings.tcpSettings.restartTcpServer = (bool)cbTcpAutomaticReconnect.IsChecked;

            // Only Store the IP Address if the Client is aktive
            if (cbClientServerSelect.SelectedItem.ToString().Equals("Client"))
            {

                userSettings.tcpSettings.ip = tbTcpIpAddress.Text;
            }

            // Return the User Settings
            return userSettings;
        }

 
        /// <summary>
        /// Client Server Selection Changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbClientServerSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Update the UI
            setIpTextBoxData();

            // Set the Event that the User Changed an Input
            OnChanged(EventArgs.Empty);
            Console.WriteLine("ServerClientSelectionChanged");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void userInputChanged(object sender, TextChangedEventArgs e)
        {
            Console.WriteLine("UserInput Changed");

            // Get the object that calls the Function
            TextBox userInputBox = sender as TextBox;
            Brush wrongInputBackground = Brushes.Red;

            // Check the IP Address
            if (userInputBox.Name == "tbTcpIpAddress" && cbClientServerSelect.SelectedItem.ToString().Equals("Client"))
            {
                // Check the IP Address
                if ((userInputBox.Text.Split('.').Length - 1) == 3)
                {
                    try
                    {
                        IPAddress.Parse(userInputBox.Text);
                        userInputBox.Background = Brushes.White;
                        dataIsValid = true;
                    }
                    catch
                    {
                        dataIsValid = false;
                        userInputBox.Background = wrongInputBackground;
                    }

                }
                else
                {
                    dataIsValid = false;
                    userInputBox.Background = wrongInputBackground;
                }
            }
            else if (userInputBox.Name == "tbTcpIpPort")
            {

                try
                {
                    if ((Convert.ToInt32(userInputBox.Text) <= 65534) && (Convert.ToInt32(userInputBox.Text) > 0))
                    {
                        dataIsValid = true;
                        userInputBox.Background = Brushes.White;
                    }
                    else
                    {
                        dataIsValid = false;
                        userInputBox.Background = wrongInputBackground;
                    }
                }
                catch
                {
                    dataIsValid = false;
                    userInputBox.Background = wrongInputBackground;
                }


            }

            // Set the Event that the User Changed an Input
            OnChanged(EventArgs.Empty);

        }

        #region On Change Eventhandler

        // An event that clients can use to be notified whenever the
        // elements of the list change.
        public event TcpIpSettingsChangedEventHandler Changed;

        // Invoke the Changed event; called whenever list changes
        protected virtual void OnChanged(EventArgs e)
        {
            if (Changed != null)
                Changed(this, e);
        }

        #endregion
    }
}
