﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net;

namespace Connecty
{
    class TcpConnection
    {
        private TcpListenerEx tcpListener;
        private Thread listenThread;
        private Thread clientThread;
        private MainWindow uiReference;
        public tcpIpSettings settings { get; set; }
        private bool stopThreads = false;
        private TcpClient tcpClient;

        /// <summary>
        /// Constructor
        /// </summary>
        public TcpConnection(MainWindow uiObject)
        {
            // Save the reference of the Main Object
            uiReference = uiObject;

            // Preset the Settings for the TCP IP Connections
            settings = new tcpIpSettings();
        }

        /// <summary>
        /// Connect the TCP Server or Client Depending on the Settings
        /// </summary>
        public void connect()
        {

            stopThreads = false;


            // Client is set up
            if(settings.clientServerSelection.Equals("Client")){
                connectClientToServer(); // 
            }// Server is set up
            else if (settings.clientServerSelection.Equals("Server"))
            {
                this.tcpListener = new TcpListenerEx(IPAddress.Any, settings.port); //IPAddress.Parse(settings.ip)
                this.listenThread = new Thread(new ThreadStart(ListenForClients));
                this.listenThread.Start();
            }

        }

        /// <summary>
        /// Disconnect the Client or the Server
        /// </summary>
        public void disconnect()
        {
            // Stop the Bakground Threads
            stopThreads = true;

            // Try to stop the Client if its Available
            if(tcpClient != null )
            {
                if (tcpClient.Connected)
                {
                    tcpClient.Close();
                }
            }


            // Try to stop the Listener
            try
            {
                this.tcpListener.Server.Close();
                this.tcpListener.Stop();

                /*while (listenThread.IsAlive)
                {
                    ;//Wait till Thread has Stopped
                }*/
            }
            catch (Exception)
            {
                ;// Double nothing
            }


        }

        /// <summary>
        /// Listen for incoming Clients
        /// </summary>
        private void ListenForClients()
        {

            // Try to start the Listener
            try
            {
                this.tcpListener.Start();
            }
            catch
            {

                // Update the UI
                updateUi("TCP Server Could not Start on Port:" + settings.port, MsgData.messageType.infoNegative);

                return;
            }


            // Set the Status Server is Startet
            updateUi("TCP Server Startet on Port:" + settings.port, MsgData.messageType.infoPositive);

            while (!stopThreads)
            {
                try
                {
                    //blocks until a client has connected to the server
                    TcpClient client = this.tcpListener.AcceptTcpClient();

                    // Set the User Hint to the TextBox
                    updateUi("Client connected with IP:" + client.Client.RemoteEndPoint.ToString(), MsgData.messageType.infoPositive);

                    //create a thread to handle communication 
                    //with connected client
                    clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                    clientThread.Start(client);

                    while (!stopThreads && client.Connected)
                    {
                        this.tcpListener.Stop();
                        Thread.Sleep(2000);
                        ;// Wait til the Client is disconnected or we want to the User wants to Disconnect

                    }

                    // Set the User Hint to the 
                    updateUi("Server Stopped", MsgData.messageType.infoNegative);
                
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error occured: " + e);

                    // Set the User Hint to the TextBox
                    updateUi("Server Stopped: ", MsgData.messageType.infoNegative);
                }
            }

        }

        /// <summary>
        /// Try to connect to a Server as Client
        /// </summary>
        public void connectClientToServer()
        {
            
            tcpClient = new TcpClient();

            IPEndPoint serverEndPoint = new IPEndPoint(IPAddress.Parse(settings.ip), settings.port);
            try
            {
                // Connect the client to the Server
                tcpClient.Connect(serverEndPoint);

                if (tcpClient.Connected)
                {
                    // Update the UI

                    // Set the User Hint to the Rich TextBox
                    updateUi("Client with Server-IP:" + tcpClient.Client.RemoteEndPoint.ToString() + "connected", MsgData.messageType.infoPositive);

                    // Start the Communication Thread
                    clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                    clientThread.Start(tcpClient);
                }
            }
            catch (Exception)
            {
                // Update the UI
                updateUi("Client could not connect to Server-IP:" + settings.ip + ":" + settings.port.ToString(), MsgData.messageType.infoNegative);

            }

        }

        /// <summary>
        /// Handling the Client Communication
        /// </summary>
        /// <param name="client"></param>
        private void HandleClientComm(object client)
        {
            MsgData logMessage;

            tcpClient = (TcpClient)client;
            NetworkStream clientStream = tcpClient.GetStream();

            byte[] message = new byte[4096];
            int bytesRead;

            while (!stopThreads)
            {
                bytesRead = 0;

                try
                {
                    //blocks until a client sends a message
                    bytesRead = clientStream.Read(message, 0, 4096);
                }
                catch
                {
                    //a socket error has occured
                    stopThreads = true;
                    break;
                }

                if (bytesRead == 0)
                {
                    //the client has disconnected from the server
                    stopThreads = true;
                    break;
                }

                // Save the Data to the 
                logMessage = new MsgData();

                // Set the Current TimeStamp
                logMessage.setCurrentTimeStamp();

                logMessage.value = new byte[bytesRead];// Create an Array with the Size of readed Data
                Array.Copy(message, logMessage.value, bytesRead);// Copy the Data to the Array
                logMessage.type = 0;//Set the Type to Recived Message


                uiReference.UpdateRTBAndSafeDataOnDifferentThread(logMessage);

            }

            // Update the UI
            updateUi("Client disconnected with IP:" + settings.ip + ":" + settings.port.ToString(), MsgData.messageType.infoNegative);

            tcpClient.Close();



        }

        /// <summary>
        /// Send Data to the Client or Server
        /// </summary>
        /// <param name="message"></param>
        public void send(MsgData message)
        {
            if (tcpClient.Connected)
            {
                NetworkStream clientStream = tcpClient.GetStream();
                clientStream.Write(message.value, 0, message.value.Length);
                clientStream.Flush();

                message.setCurrentTimeStamp();// Set the Time Stamp
                message.type = MsgData.messageType.send;// Set the Msg Type 1 = Send

                // Update the UI with the Log Window
                uiReference.UpdateRTBAndSafeDataOnDifferentThread(message);
            }

        }


        #region UI Update functions


        /// <summary>
        /// Update the ui With an Log Message and trigger the UpdateStatusBar
        /// </summary>
        /// <param name="rtbMsg">Message for the Log Window</param>
        /// <param name="msgType">Msg Type</param>
        private void updateUi(string rtbMsg, MsgData.messageType msgType)
        {

            // Set the User Hint to the TextBox
            MsgData logMessage = new MsgData();
            logMessage.value = Encoding.ASCII.GetBytes(rtbMsg);
            logMessage.type = msgType;

            uiReference.UpdateRTBAndSafeDataOnDifferentThread(logMessage);

        }

        #endregion


        public int getConnectionState()
        {
            int connectionState = 0;

            try
            {

                // Check the TCP Client
                if (this.tcpClient != null)
                {
                    // uiReference.UpdateStatusBarOnDifferentThread(ConnectionState);
                    if (this.tcpClient.Connected)
                    {
                        connectionState = 3;
                    }
                    else if (!(this.tcpClient.Connected))
                    {
                        connectionState = 0;
                    }

                }

                // Check the Listener State
                if (this.tcpListener != null)
                {
                    if (this.tcpListener.Active)
                    {
                        connectionState = 1;
                    }
                    else if (this.tcpClient == null)
                    {
                        connectionState = 0;

                    }
                }


            }
            // Something unpredicted happend
            catch (Exception err)
            {
                connectionState = 0;
            }

            // Return the current State
            return connectionState;
        }

    }
}
