﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Connecty
{
    /// <summary>
    /// This Function is used to Handle the Different Connections through only one Interface
    /// </summary>
    class ConnectionInterface
    {
        // Define some Variables 
        public ConnectionSettings connectionSettings { get; set; }
        private TcpConnection tcpConnection;// Connection Object for the TCP IP Connection
        private rs232Connection serialConnection;// Connection Object for the Serial Connection

        private MainWindow uiRef; // Reference to the UI
        private System.Threading.Timer stateTimer; // Timer for the Asynchronous update of the Statusbar

        /// <summary>
        /// Construktor
        /// </summary>
        /// <param name="obj"></param>
        public ConnectionInterface(MainWindow obj)
        {
            // Set the UI Reference
            this.uiRef = obj;
        }

        /// <summary>
        /// Connect Method
        /// </summary>
        public void Connect()
        {

            // First of all we call the Disconnect. Maybe their is a Connection allready Running
            Disconnect();

            // Start the StatusBar Update Ticker
            stateTimer = new System.Threading.Timer(new TimerCallback(updateStatusBar_Tick));
            stateTimer.Change(0, 200);

            if (connectionSettings.currentConnectionSetting == 1)
            {
                // If the Object Ref is NUll create a new one
                if (tcpConnection == null)
                {
                    tcpConnection = new TcpConnection(uiRef);
                }

                tcpConnection.settings = connectionSettings.tcpSettings;
                tcpConnection.connect();
            }
            else if (connectionSettings.currentConnectionSetting == 2)
            {
                if (serialConnection == null)
                {
                    // First try to Disconnect
                    serialConnection = new rs232Connection(uiRef);
                }

                serialConnection.pcSerialParam = connectionSettings.serialSettings;
                serialConnection.connect();
            }
        }

        /// <summary>
        /// Disconnecting Method
        /// </summary>
        public void Disconnect()
        {
            if (tcpConnection != null)
            {
                tcpConnection.disconnect();
            }

            if (serialConnection != null)
            {
                serialConnection.disconnect();
            }
        }

        /// <summary>
        /// Try to send the Data to the Requested Connection
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public int Send(MsgData message)
        {

            if (connectionSettings.currentConnectionSetting == 1)
            {
                if (tcpConnection != null)
                {
                    tcpConnection.send(message);
                }
            }
            else if (connectionSettings.currentConnectionSetting == 2)
            {
                if (serialConnection != null)
                {
                    serialConnection.send(message);
                }
            }

            return 1;

        }

        /// <summary>
        /// Update the Statusbar
        /// </summary>
        private void updateStatusBar_Tick(object state)
        {

            if (connectionSettings.currentConnectionSetting == 1)
            {
                if (tcpConnection != null)
                {
                    uiRef.UpdateStatusBarOnDifferentThread(tcpConnection.getConnectionState());
                }
            }
            else if (connectionSettings.currentConnectionSetting == 2)
            {
                if (serialConnection != null)
                {
                    uiRef.UpdateStatusBarOnDifferentThread(serialConnection.getConnectionState());
                }
            }
        }
    }
}
