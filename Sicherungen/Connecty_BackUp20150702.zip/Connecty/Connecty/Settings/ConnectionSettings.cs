﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Connecty
{
    [Serializable()]
    public class ConnectionSettings : ISerializable
    {

        public int currentConnectionSetting { get; set; }  // 1 = TCP IP / 2 = RS232
        public rs232Settings serialSettings { get; set; } // Com Port Settings
        public tcpIpSettings tcpSettings { get; set; } // TCP Settings


        /// <summary>
        /// Construtor
        /// </summary>
        public ConnectionSettings()
        {
            currentConnectionSetting = 1;
            serialSettings = new rs232Settings();
            tcpSettings = new tcpIpSettings();

        }


        /// <summary>
        /// Function that returns a Human readable Text of the Current Settungs
        /// This Text can be displayed to the user
        /// </summary>
        /// <returns></returns>
        public string getSettingsInfo()
        {
            string sSettingsAsText;

            if (currentConnectionSetting == 1)
            {
                sSettingsAsText = "TCP: " + tcpSettings.clientServerSelection + " @";

                if(tcpSettings.clientServerSelection == "Client")
                {
                    sSettingsAsText += tcpSettings.ip;
                }

                else if (tcpSettings.clientServerSelection == "Server")
                {
                    sSettingsAsText += "Alle vorhandenen IP's";
                }

                sSettingsAsText += (":" + tcpSettings.port.ToString());
            
            }
            else if (currentConnectionSetting == 2)
            {
                sSettingsAsText = "Seriell: @" + serialSettings.port;
            }
            else
            {
                sSettingsAsText = "";
            }

            return sSettingsAsText;
        }


        /// <summary>
        /// Serialize helper function to get the saved data from the File
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ctxt"></param>
        public ConnectionSettings(SerializationInfo info, StreamingContext ctxt)
        {
            this.currentConnectionSetting = (int)info.GetValue("connection", typeof(int));
            this.serialSettings = (rs232Settings)info.GetValue("rs232Settings", typeof(rs232Settings));
            this.tcpSettings = (tcpIpSettings)info.GetValue("tcpIpSettings", typeof(tcpIpSettings));
        }

        /// <summary>
        /// Serialize helper function to write the data to the File
        /// </summary>
        /// <param name="info"></param>
        /// <param name="ctxt"></param>
        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("connection", this.currentConnectionSetting);
            info.AddValue("rs232Settings", this.serialSettings);
            info.AddValue("tcpIpSettings", this.tcpSettings);
        }
        

    }
}
