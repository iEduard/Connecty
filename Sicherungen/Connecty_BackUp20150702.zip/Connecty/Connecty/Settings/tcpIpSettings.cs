﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Connecty
{
    [Serializable()]
    public class tcpIpSettings : ISerializable
    {
        /// <summary>
        ///  Define the Class Variables
        /// </summary>
        public int port { get; set; } // Port
        public string ip { get; set; } // IP-Address
        public string clientServerSelection { get; set; } // Client Server selection Client = 1 / Server = 2

        public tcpIpSettings()
        {
            // Preset the Settings
            port = 3000;
            ip = "192.168.0.1";
            clientServerSelection = "Client";

        }

        public tcpIpSettings(SerializationInfo info, StreamingContext ctxt)
        {
            this.port = (int)info.GetValue("tcpIpPort", typeof(int));
            this.ip = (string)info.GetValue("tcpIpIp", typeof(string));
            this.clientServerSelection = (string)info.GetValue("tcpIpServerClient", typeof(string));

        }

        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("tcpIpPort", this.port);
            info.AddValue("tcpIpIp", this.ip);
            info.AddValue("tcpIpServerClient", this.clientServerSelection);
        }
    }
}
