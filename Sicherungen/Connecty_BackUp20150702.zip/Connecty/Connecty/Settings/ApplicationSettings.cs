﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace Connecty
{
    [Serializable()]
    public class ApplicationSettings : ISerializable
    {

        /// <summary>
        ///  Define the Class Variables
        /// </summary>
        public bool showTimeStamp { get; set; }              // TRUE := Show the TimeStamp in the Message Log // FALSE := Hide the TimeStamp in the Message Log
        public int msgLogRingBufferSize { get; set; }        // Size of the Ringbuffer for the Msg Log
        public int sendHistorySize { get; set; }             // Count of stored Send Messages 
        public bool restartTcpServer { get; set; }           // TRUE := Open up the Server again after a Disconnect // FALSE := Stay disconnected


        /// <summary>
        /// Constructor
        /// </summary>
        public ApplicationSettings()
        {
            showTimeStamp = true;
            msgLogRingBufferSize = 4096;
            sendHistorySize = 20;
            restartTcpServer = true;
        }




        public ApplicationSettings(SerializationInfo info, StreamingContext ctxt)
        {
            this.showTimeStamp = (bool)info.GetValue("showTimeStamp", typeof(bool));
            this.msgLogRingBufferSize = (int)info.GetValue("msgLogRingBufferSize", typeof(int));
            this.sendHistorySize = (int)info.GetValue("sendHistorySize", typeof(int));
            this.restartTcpServer = (bool)info.GetValue("restartTcpServer", typeof(bool));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("showTimeStamp", this.showTimeStamp);
            info.AddValue("msgLogRingBufferSize", this.msgLogRingBufferSize);
            info.AddValue("sendHistorySize", this.sendHistorySize);
            info.AddValue("restartTcpServer", this.restartTcpServer);
        }


    }
}
