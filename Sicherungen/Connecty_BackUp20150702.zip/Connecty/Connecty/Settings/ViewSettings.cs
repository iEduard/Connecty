﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace Connecty
{
    [Serializable()]
    public class ViewSettings : ISerializable
    {

        /// <summary>
        ///  Define the Class Variables
        /// </summary>
        public bool showTimeStamp { get; set; }              // TRUE := Show the TimeStamp in the Message Log // FALSE := Hide the TimeStamp in the Message Log

        /// <summary>
        /// the Current Settings for the view 
        /// 0 = Standard ASCII Signs as a String 
        /// 1 = ASCII Encoding HEX Values
        /// 2 = ASCII Encoding Decimal Values
        /// 3 = ASCII Encoding Binary Values
        /// </summary>
        public int dataPresentation { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        public ViewSettings()
        {
            showTimeStamp = false;
            dataPresentation = 0; // Default show the ASCII Signs
        }


        public ViewSettings(SerializationInfo info, StreamingContext ctxt)
        {
            this.showTimeStamp = (bool)info.GetValue("showTimeStamp", typeof(bool));
            this.dataPresentation = (int)info.GetValue("dataPresentation", typeof(int));
        }

        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            info.AddValue("showTimeStamp", this.showTimeStamp);
            info.AddValue("dataPresentation", this.dataPresentation);
        }


    }
}
